from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from enum import Enum

class StatusEnum(str, Enum):
    pending = "Pending"
    in_progress = "InProgress"
    completed = "Completed"

class PriorityEnum(str, Enum):
    low = "Low"
    medium = "Medium"
    high = "High"

class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    due_date: datetime
    status: StatusEnum = StatusEnum.pending
    priority: PriorityEnum = PriorityEnum.medium
    user_id: int

class TaskCreate(TaskBase):
    pass

class TaskResponse(TaskBase):
    id: int

    class Config:
        orm_mode = True
