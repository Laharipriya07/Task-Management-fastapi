from fastapi import FastAPI
from routers import user_router, task_router
from fastapi.responses import JSONResponse

app = FastAPI(title="TaskHub API")

app.include_router(user_router.router, prefix="/api/users", tags=["Users"])
app.include_router(task_router.router, prefix="/api/tasks", tags=["Tasks"])

@app.get("/")
def read_root():
    return JSONResponse(content={
        "message": "🚀 Welcome to TaskHub API!",
        "docs": "Visit /docs to explore the API"
    })