from sqlalchemy.orm import Session
from models.task import TaskItem
from schemas.task_schema import TaskCreate

def get_all_tasks(db: Session):
    return db.query(TaskItem).all()

def get_task_by_id(db: Session, task_id: int):
    return db.query(TaskItem).filter(TaskItem.id == task_id).first()

def get_tasks_by_user_id(db: Session, user_id: int):
    return db.query(TaskItem).filter(TaskItem.user_id == user_id).all()

def create_task(db: Session, task: TaskCreate):
    new_task = TaskItem(
        title=task.title,
        description=task.description,
        due_date=task.due_date,
        status=task.status,
        priority=task.priority,
        user_id=task.user_id
    )
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    return new_task

def update_task(db: Session, task_id: int, task_data: TaskCreate):
    task = get_task_by_id(db, task_id)
    if task:
        task.title = task_data.title
        task.description = task_data.description
        task.status = task_data.status
        task.priority = task_data.priority
        task.due_date = task_data.due_date
        task.user_id = task_data.user_id
        db.commit()
        db.refresh(task)
    return task

def delete_task(db: Session, task_id: int):
    task = get_task_by_id(db, task_id)
    if task:
        db.delete(task)
        db.commit()
    return task
